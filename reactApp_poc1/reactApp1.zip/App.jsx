import React from 'react';

class App extends React.Component { 
    render() {
      return (
          <div>
            <Content>This is a very nice comment</Content> 
            <Content>This will produce following result</Content>  
          </div>
      );
   }
}

class Content extends React.Component{    

    constructor(props){
        super(props);
            this.state = { //this is same as getInitialState
                checked: true,
                editing: false
            }
    }

    handleChecked(){    
        this.setState({checked: !this.state.checked})  
    };

    edit(){
        this.setState({editing:true});
    };
    
    save(){
        var textVal =  this.refs.updateText.value;
        alert(textVal)
        this.setState({editing:false});
    }
    
    remove(){
        console.log('You clicked on remove');
    }; 
    
    renderNormal(){
       return(
           <div className="commentContent">
                <div>
                    <h3>{this.props.children}</h3>
                    <button className="blue" onClick={this.edit.bind(this)}>Edit</button>
                    <button className="red" onClick={this.remove}>Remove</button>
                     
                </div> 
            </div> 
        );    
    };
    
    renderForm(){
        return(
           <div className="commentContent">
                <div>
                    <textarea ref="updateText" defaultValue={this.props.children}></textarea>
                    <button className="green" onClick={this.save.bind(this)}>Save</button>                    
                     
                </div> 
            </div> 
        );        
    }
    
    render(){
         
       
            if(!this.state.editing)
                 return  (this.renderNormal());
            else
                return (this.renderForm());
          
    }
}

 

export default App;