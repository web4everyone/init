import React, { Component }  from 'react'
import { Router, Route, Link, IndexRoute, hashHistory, browserHistory } from 'react-router'
import NavUrl from './NavUrl.jsx'; 
class Users extends React.Component {
  render () {
        return (
          <div>
            <ul className="nav-links">  
                <li><IndexLink to="/" activeClassName="active">Home</IndexLink></li>
                <li><NavUrl to="/groups">Groups</NavUrl></li>
                <li><NavUrl to="/users">Users</NavUrl></li>
            </ul>
              <h3>Users</h3>
          </div>
        )
      }
}
    
export default Users;      

